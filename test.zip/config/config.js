module.exports = {
  development: {
    username: process.env.DEV_DB_USERNAME,
    password: process.env.DEV_DB_PASSWORD,
    database: process.env.DEV_DB_DATABASE,
    host: process.env.DEV_DB_HOST,
    dialect: process.env.DEV_DB_DIALECT,
    port: process.env.DEV_DB_PORT
  },
  test: {
    username: "root",
    password: null,
    database: "chatbot_db",
    host: "127.0.0.1",
    dialect: "mysql"
  },
  production: {
    username: `${process.env.PROD_DB_USERNAME}`,
    password: `${process.env.PROD_DB_PASSWORD}`,
    database: `${process.env.PROD_DB_DATABASE}`,
    host: `${process.env.PROD_DB_HOST}`,
    dialect: `mysql`,
    port: process.env.PROD_DB_PORT,
    // pool configuration used to pool database connections
    pool: {
      max: 5,
      min: 0,
      idle: 20000,
      acquire: 20000
    },
    logging: console.log,

  }
}


// module.exports = {
//   development: {
//     username: "root",
//     password: null,
//     database: "chatbot_db",
//     host: "127.0.0.1",
//     dialect: "mysql"
//   },
//   test: {
//     username: "root",
//     password: null,
//     database: "chatbot_db",
//     host: "127.0.0.1",
//     dialect: "mysql"
//   },
//   production: {
//     username: "karb6351",
//     password: "david05027",
//     database: "chatbotdb",
//     host: "chatbotdb.cfl3m0hqubpz.us-east-2.rds.amazonaws.com",
//     dialect: "mysql"
//   }
// }
