<template>
  <div>
    
  </div>
</template>

<script>
  export default {
    name: 'route'
  }
</script>

<style scoped>

</style>