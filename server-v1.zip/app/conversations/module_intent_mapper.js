

module.exports = {
  tour_route: new (require('./modules/tour_route'))().intentType(),
  general: new (require('./modules/general'))().intentType(),
  restaurant: new (require('./modules/restaurant'))().intentType(),
  food: [

  ],
  local_knowledge: [

  ]
}