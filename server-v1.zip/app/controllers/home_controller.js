exports.index = (req, res, next) => {
  res.render('pages/home/index');
}